SGBSTDN.SGBSTDN_LEVL_CODE in ('UG')
and SHRTGPA.SHRTGPA_GPA = 4 and shrtgpa.shrtgpa_gpa_hours >= 12.000