exists(
        select *

        from SFRSTCR SFRSTCR

        where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
              and SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
              and SFRSTCR.SFRSTCR_RSTS_CODE in ('RE','RW')
    )

order by 
    STVMAJR.STVMAJR_DESC, SPRIDEN.SPRIDEN_SEARCH_LAST_NAME