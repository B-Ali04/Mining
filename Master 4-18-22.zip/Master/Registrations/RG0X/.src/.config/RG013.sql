exists(
    select *

    from SGRSATT SGRSATT

    where SGRSATT.SGRSATT_PIDM = SPRIDEN.SPRIDEN_PIDM
          and SGRSATT.SGRSATT_ATTS_CODE in ('CNCL', 'CNCE', 'CNCC','CNCM', 'CNCX','CNCN','CNCO')
    )

and exists(
        select *

        from SFRSTCR SFRSTCR

        where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
              and SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
              and SFRSTCR.SFRSTCR_RSTS_CODE in ('RE','RW')
    )