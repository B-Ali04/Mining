SELECT email_address,
      username,
      auth_identifier,
      card_id,
      first_name,
      last_name,
      middle_name,
      preferred_name,
      case when classstanding='FR' THEN 'Freshman'
           when classstanding='SO' THEN 'Sophomore'
           when classstanding='JR' THEN 'Junior'
           when classstanding IN ('SR','S5') THEN 'Senior'
           when classstanding='AG' THEN
                CASE WHEN DEGREESOUGHT LIKE 'C%' THEN 'Certificate Program'
                     WHEN DEGREESOUGHT LIKE 'N%' THEN 'Certificate Program'
                     WHEN DEGREESOUGHT LIKE 'M%' THEN 'Masters'
                     WHEN DEGREESOUGHT LIKE 'P%' THEN 'Doctorate'
                     else concat('DS?? ',degreesought) END
           else concat('CS?? ',classstanding)
           END AS school_year_name,
      case when degreesought = 'AAS' THEN 'Associates'
           when degreesought LIKE 'C%' THEN 'Certificate'
           when degreesought in ('BS','BLA') THEN 'Bachelors'
           when degreesought like 'M%' THEN 'Masters'
           when degreesought like 'P%' THEN 'Doctorate'
           when degreesought like 'N%' THEN 'Non-degree Seeking'
           else concat('DS?? ',degreesought)
           end as education_level_name,
      cumulative_gpa,
      department_gpa,
      primary_major_name,
      case when major2_name is null then primary_major_name else concat(concat(primary_major_name,';'),major2_name) end as major_names,
      minor_name,
      college_name,
      start_date,
      end_date,
      currently_attending,
      campus_name,
      case when ethnicity is not null and Race is not null then concat(concat(ethnicity,'> '),race)
           when ethnicity is not null then ethnicity
           else race end as ethnicity,
      gender,
      disabled_f,
      work_study,
      label_names,
      case when length(mobilephone) < 10 then '' else mobilephone end as mobilephone,
      assignedto_email,
      Hometown,
      athlete,
      first_gen,
      veteran,
      gd_pr,
      SISID,
      styp_code,
      careerlevel,
      registered,
      deccd,
      decdt,
      pidm,
      TO_DATE(to_char(SYSDATE,'MM/DD/YYYY'),'MM/DD/YYYY') AS AsOf
FROM (
       select DISTINCT
       concat(d.gobtpac_external_user,'@esf.edu') as email_address
       ,b1.goradid_additional_id as username
       ,d.gobtpac_external_user as auth_identifier
       ,b1.goradid_additional_id as card_id
       ,a.spriden_first_name as First_Name
       ,a.spriden_last_name as Last_Name
       ,a.spriden_mi as Middle_Name
       ,CASE when p.spbpers_pref_first_name is not null then p.spbpers_pref_first_name else '' end as Preferred_Name
       ,SGKCLAS.F_CLASS_CODE(ts.sgbstdn_pidm, ts.sgbstdn_levl_code, :MaxTerm.CODE) as ClassStanding
--             WHEN ts.sgbstdn_degc_code_1 like 'C%' THEN 'Certificate Program'
--             WHEN ts.sgbstdn_degc_code_1 like 'M%' THEN 'Masters'
--             WHEN ts.sgbstdn_degc_code_1 like 'P%' THEN 'Doctorate'
--             ELSE SGKCLAS.F_CLASS_CODE(ts.sgbstdn_pidm, ts.sgbstdn_levl_code, :MaxTerm.CODE)
--             END as ClassStanding
       ,ts.sgbstdn_degc_code_1 as DegreeSought
--       ,CASE when ts.sgbstdn_degc_code_1 = 'AAS' THEN 'Associates'
--             WHEN ts.sgbstdn_degc_code_1 like 'C%' THEN 'Certificate'
--             WHEN ts.sgbstdn_degc_code_1 = 'BS' THEN 'Bachelors'
--             WHEN ts.sgbstdn_degc_code_1 like 'M%' THEN 'Masters'
--             WHEN ts.sgbstdn_degc_code_1 like 'P%' THEN 'Doctorate'
--             WHEN ts.sgbstdn_degc_code_1 like 'N%' THEN 'Non-degree Seeking'
--             end as DegreeSought
       ,lgpa.shrlgpa_gpa as cumulative_gpa
       ,0.00 as department_gpa
       ,pg.smrprle_program_desc as primary_major_name
       ,pg2.smrprle_program_desc as major2_name
       ,minr.stvmajr_desc as minor_name
       ,'' as college_name
       ,at.stvterm_start_date as Start_date
       ,et.stvterm_end_date as End_date
       ,case when reg.sfrstcr_pidm is not null then 'TRUE' else 'FALSE' end as Currently_Attending
       ,case when ts.sgbstdn_camp_code='M' then 'Main'
             when ts.sgbstdn_camp_code='OL' then 'On-line'
             else ts.sgbstdn_camp_code
             end as Campus_name
       ,case when p.spbpers_ethn_cde = '1' then 'Not Hispanic or Latino'
             when p.spbpers_ethn_cde = '2' then 'Hispanic or Latino'
             else '' end as Ethnicity
--       ,'' as Ethnicity
       ,(case when p.spbpers_sex = 'M' then 'Male' when p.spbpers_sex = 'F' then 'Female' else 'N/A' end) as Gender
       ,'' as disabled_f
       ,'' as work_study
       ,'' as label_names
       ,replace(replace(replace(replace(concat(ph.sprtele_phone_area,ph.sprtele_phone_number),'-'),'+'),')'),'(') as MobilePhone
       ,'' as assignedto_email
       ,p.spbpers_city_birth as Hometown
       ,'' as athlete
       ,'' as first_gen
       ,'' as veteran
       ,'' as gd_pr
       ,a.spriden_id as SISID
--       ,case when p.spbpers_ethn_code is not null then e.stvethn_Desc else '' end as Old_Ethnicity
       ,aggr.Race_Desc as Race
       ,ts.sgbstdn_styp_code as styp_code

--       'Student' as Affiliation,
--       concat(ph.sprtele_phone_area,ph.sprtele_phone_number) as MobilePhone,
--       SUBSTR(TO_CHAR(p.spbpers_birth_date,'MM/DD/YYYY'),1,10) as DateOfBirth,
--       r.gorrace_desc as Race,
--       aggr.race_desc as Race,
--       e.stvethn_Desc as Ethnicity,
--       CASE WHEN SFRTHST_PIDM IS NULL THEN 'Unknown' ELSE STVTMST_DESC END AS EnrollmentStatus,
--       (select stvterm_desc from stvterm where stvterm_code = (Select max(sfrstcr_term_code) from sfrstcr where sfrstcr_pidm=a.spriden_pidm and sfrstcr_rsts_code='RE')) as CurrentTermEnrolled,
--       gpa1.shrtgpa_gpa as CurrentTermGPA,
--       (select stvterm_desc from stvterm where stvterm_code = (Select max(r1.sfrstcr_term_code) from sfrstcr r1 where r1.sfrstcr_pidm=a.spriden_pidm and r1.sfrstcr_rsts_code='RE' and r1.sfrstcr_term_code < (Select max(r2.sfrstcr_term_code) as maxt2 from sfrstcr r2 where r2.sfrstcr_pidm=a.spriden_pidm and r2.sfrstcr_rsts_code='RE'))) as PreviousTermEnrolled,
--       gpa2.shrtgpa_gpa as PreviousTermGPA,
--       agg1.HRS_Earned as CreditHoursEarned,
--       ts.sgbstdn_exp_grad_date as AnticipatedDateOfGraduation,
       ,case when ts.sgbstdn_styp_code in ('T','F','C','U') then 'UnderGrad' when ts.sgbstdn_styp_code in ('N','D','G','R') then 'Grad' else 'Other' end as CareerLevel
--       (select stvdept_desc from stvdept where stvdept_code = ts.sgbstdn_dept_code) as PrimarySchoolOfEnrollment,
--       '' as PrimarySchoolOfEnrollment,
--       pg.smrprle_program_desc as Major,
--       ts.sgbstdn_majr_code_minr_1, -- as Minor
--       av.PRIMARY_ADVR_NAME as MajorAdvisor,
--       concat(concat(spv.spriden_First_name,' '), spv.spriden_Last_name) as MajorAdvisor,
--       concat(concat(s2p.spriden_First_name,' '), s2p.spriden_Last_name) as OtherAdvisor,
--       CASE WHEN ts.SGBSTDN_CAMP_CODE = 'OL' THEN 'On-Line' WHEN ts.SGBSTDN_CAMP_CODE = 'RS' THEN 'Ranger School' ELSE CASE WHEN ch.SLRRASG_PIDM is null then 'Off-Campus' else 'On-Campus' end END as LocalResidencyStatus,
--       CASE WHEN ch.SLRRASG_PIDM is null then '' else 'Centennial Hall' end as HousingFacility,
--       case when ts.sgbstdn_resd_code='F' THEN 'TRUE' when p.spbpers_citz_code = 'N' THEN 'TRUE' ELSE 'FALSE' END as International,
--       case when ts.sgbstdn_styp_code in ('T','G') THEN 'TRUE' ELSE 'FALSE' END AS Transfer,
--       '' as Athlete,
--       '' as AthleteParticipation,
--       adl.spraddr_ctry_code_phone as LocalPhoneCountryCode,
--       concat(adl.spraddr_phone_area,adl.spraddr_phone_number) as LocalPhone,
--       adl.spraddr_phone_ext as LocalPhoneExtension,
--       adl.spraddr_street_line1 as LocalStreet1,
--       adl.spraddr_street_line2 as LocalStreet2,
--       adl.spraddr_street_line3 as LocalStreet3,
--       adl.spraddr_city as LocalCity,
--       adl.spraddr_stat_code as LocalStateProvince,
--       adl.spraddr_zip as LocalPostalCode,
--       adl.spraddr_natn_code as LocalCountry,
--       adh.spraddr_ctry_code_phone as HomePhoneCountryCode,
--       concat(adh.spraddr_phone_area,adh.spraddr_phone_number) as HomePhone,
--       adh.spraddr_phone_ext as HomePhoneExtension,
--       adh.spraddr_street_line1 as HomeStreet1,
--       adh.spraddr_street_line2 as HomeStreet2,
--       adh.spraddr_street_line3 as HomeStreet3,
--       adh.spraddr_city as HomeCity,
--       adh.spraddr_stat_code as HomeStateProvince,
--       adh.spraddr_zip as HomePostalCode,
--       adh.spraddr_natn_code as HomeCountry,
--       '' as AbroadPhoneCountryCode,
--       '' as AbroadPhone,
--       '' as AbroadPhoneExtension,
--       '' as AbroadStreet1,
--       '' as AbroadStreet2,
--       '' as AbroadStreet3,
--       '' as AbroadCity,
--       '' as AbroadStateProvince,
--       '' as AbroadPostalCode,
--       '' as AbroadCountry,
--       p.spbpers_gndr_code as GNDR,
--       p.spbpers_pprn_code as PPRN,
--      (select stvnatn_nation from stvnatn where stvnatn_code=i.gobintl_natn_code_birth) as BIRTH_COUNTRY,
--       v.gorvisa_vtyp_code as VISA_TYPE,
--       v.gorvisa_natn_code as ISSUED_BY,
--       p.spbpers_citz_code as US_CITZ,
--       (select stvnatn_nation from stvnatn where stvnatn_code=i.gobintl_natn_code_legal) as CITIZENSHIP,
--       ts.sgbstdn_styp_code AS Student_Type,
--       ts.sgbstdn_stst_code as Student_Status,
       ,CASE WHEN reg.sfrstcr_pidm is not null THEN 'EN'
             WHEN ap2.sarappd_apdc_code is null then case when sgbstdn_term_code_eff >= :MinTerm.CODE and sgbstdn_term_code_eff <= :MaxTerm.CODE then 'AX' else 'XX' end
             ELSE ap2.sarappd_apdc_code END as Deccd
       ,ap2.sarappd_apdc_date as DecDt
       ,case when reg.sfrstcr_pidm is not null then 'Yes' else 'No' end as Registered
--       CASE WHEN ap2.sarappd_pidm is null THEN SYSDATE ELSE ap2.sarappd_apdc_date END as Dec_Date,
--       ap2.sarappd_apdc_date as Dec_Date,
--       concat(concat(sgbstdn_degc_code_1,': '),pg.smrprle_program_desc) as program,
--       ts.sgbstdn_camp_code as Campus,
--       ph.sprtele_intl_access as c_intl_access,
--       concat(ph.sprtele_phone_area,ph.sprtele_phone_number) as c_phone,
--       case when ts.sgbstdn_styp_code in ('T','F','C','U') then 'UnderGrad' when ts.sgbstdn_styp_code in ('N','D','G','R') then 'Grad' else 'Other' end as Cat,
--       ts.sgbstdn_term_code_admit as Admit_Term,
--       case when reg.sfrstcr_pidm is null THEN 'No' else 'Yes' end as Registered,
         ,a.spriden_pidm as PIDM
--       ch.*,
--       ad.*
       from spriden a
       INNER JOIN sgbstdn ts on (ts.sgbstdn_pidm=a.spriden_pidm)
       INNER JOIN spbpers p on (a.spriden_pidm=spbpers_pidm)
       left outer join shrlgpa lgpa on (a.spriden_pidm=lgpa.shrlgpa_pidm and lgpa.shrlgpa_levl_code=ts.sgbstdn_levl_code and lgpa.shrlgpa_gpa_type_ind='I')
--       LEFT OUTER JOIN agg_student_level_gpa agg1 ON (a.spriden_pidm=agg1.PIDM and agg1.GPA_TYPE='O' AND agg1.LEVL_CODE=ts.sgbstdn_levl_code)
       LEFT OUTER JOIN agg_race aggr on (a.spriden_pidm=aggr.PIDM)
       LEFT OUTER JOIN smrprle pg on (ts.sgbstdn_program_1=pg.smrprle_program)
       LEFT OUTER JOIN smrprle pg2 on (ts.sgbstdn_program_2=pg2.smrprle_program and ts.sgbstdn_program_1 <> ts.sgbstdn_program_2 and ts.sgbstdn_degc_code_1 = ts.sgbstdn_degc_code_2)
       LEFT OUTER JOIN stvmajr minr on (ts.sgbstdn_majr_code_minr_1=minr.stvmajr_code)
       LEFT OUTER JOIN goradid b1 on (b1.goradid_pidm=a.spriden_pidm and b1.goradid_adid_code='SUID')
       LEFT OUTER JOIN goradid b2 on (b2.goradid_pidm=a.spriden_pidm and b2.goradid_adid_code='SUNI')
       LEFT OUTER JOIN gobumap c on (c.gobumap_pidm=a.spriden_pidm)
       LEFT OUTER JOIN gobtpac d on (d.gobtpac_pidm=a.spriden_pidm)
       LEFT OUTER JOIN gobintl i on (a.spriden_pidm=i.gobintl_pidm)
       left OUTER JOIN gorvisa v on (a.spriden_pidm=v.gorvisa_pidm)
       LEFT OUTER JOIN sprtele ph on (a.spriden_pidm=ph.sprtele_pidm and ph.sprtele_tele_code='PC' and ph.sprtele_status_ind is null and ph.sprtele_seqno = (select max(ph2.sprtele_seqno) from sprtele ph2 where a.spriden_pidm=ph2.sprtele_pidm and ph2.sprtele_tele_code='PC' and ph2.sprtele_status_ind is null))
       LEFT OUTER JOIN GOREMAL e on (a.spriden_pidm=e.goremal_pidm and e.goremal_emal_code='SU')
       left outer join stvterm at on (ts.sgbstdn_term_code_admit=at.stvterm_code)
       left outer join stvterm et on (ts.sgbstdn_term_code_grad=et.stvterm_code)
--       LEFT OUTER JOIN GOREMAL pe on (a.spriden_pidm=pe.goremal_pidm and pe.goremal_emal_code='PERS' AND pe.goremal_status_ind = 'A' and INSTR(pe.goremal_email_address,'@syr.edu') = 0)
--       LEFT OUTER JOIN AGG_STUDENT_ADVISOR av ON (a.spriden_pidm=av.PIDM and av.TERM_CODE=:MaxTerm.CODE)
--       LEFT OUTER JOIN SGRADVR av on (a.spriden_pidm=av.sgradvr_pidm and av.sgradvr_prim_ind='Y' and av.sgradvr_term_code_eff = (select max(av1.sgradvr_term_code_eff) as maxterm from sgradvr av1 where av1.sgradvr_pidm=a.spriden_pidm))
--       LEFT OUTER JOIN SPRIDEN spv on (av.sgradvr_advr_pidm=spv.spriden_pidm and spv.spriden_change_ind is null)
--       LEFT OUTER JOIN SGRADVR a2v on (a.spriden_pidm=a2v.sgradvr_pidm and a2v.sgradvr_prim_ind<>'Y' and a2v.sgradvr_term_code_eff = (select max(av2.sgradvr_term_code_eff) as maxterm from sgradvr av2 where av2.sgradvr_pidm=a.spriden_pidm))
--       LEFT OUTER JOIN SPRIDEN s2p on (a2v.sgradvr_advr_pidm=s2p.spriden_pidm and s2p.spriden_change_ind is null)
       LEFT OUTER JOIN STVETHN e on (p.spbpers_ethn_code = e.stvethn_code)
--       LEFT OUTER JOIN GORPRAC prac on (a.spriden_pidm=prac.gorprac_pidm)
--       LEFT OUTER JOIN GORRACE r on (prac.gorprac_race_cde=r.gorrace_race_cde)
       LEFT OUTER JOIN SFRSTCR reg on (a.spriden_pidm=reg.sfrstcr_pidm and reg.sfrstcr_term_code >= :MinTerm.CODE and reg.sfrstcr_term_code <= :MaxTerm.CODE and reg.sfrstcr_rsts_code = 'RE')
       left outer join sfrthst on (sfrthst_pidm=a.spriden_pidm and sfrthst_term_code >= :MinTerm.CODE and sfrthst_term_code <= :MaxTerm.CODE and sfrthst_SURROGATE_ID= (select max(b.sfrthst_SURROGATE_ID) from sfrthst b where b.sfrthst_pidm = a.spriden_pidm and b.sfrthst_term_code >= :MinTerm.CODE and b.sfrthst_term_code <=:MaxTerm.CODE))
       left outer join stvtmst on (sfrthst_tmst_code = stvtmst_code)
       left outer join shrtgpa gpa1 on (a.spriden_pidm=gpa1.shrtgpa_pidm and gpa1.shrtgpa_gpa_type_ind = 'I' and gpa1.shrtgpa_levl_code=ts.sgbstdn_levl_code and gpa1.shrtgpa_term_code = (Select max(sfrstcr_term_code) from sfrstcr where sfrstcr_pidm=a.spriden_pidm and sfrstcr_rsts_code='RE'))
       left outer join shrtgpa gpa2 on (a.spriden_pidm=gpa2.shrtgpa_pidm and gpa2.shrtgpa_gpa_type_ind = 'I' and gpa2.shrtgpa_levl_code=ts.sgbstdn_levl_code and gpa2.shrtgpa_term_code = (select max(gpax.shrtgpa_term_code) as maxterm from shrtgpa gpax where gpax.shrtgpa_pidm=a.spriden_pidm and gpax.shrtgpa_term_code < (Select max(sfrstcr_term_code) from sfrstcr where sfrstcr_pidm=a.spriden_pidm and sfrstcr_rsts_code='RE')))
--       LEFT OUTER JOIN SPRADDR adl on (a.spriden_pidm=adl.spraddr_pidm and adl.spraddr_status_ind is null and concat(adl.spraddr_atyp_code,to_char(adl.spraddr_seqno,'009')) = (select max(CONCAT(ad2.spraddr_atyp_code,TO_CHAR(ad2.spraddr_seqno,'009'))) as maxcode from spraddr ad2 where ad2.spraddr_pidm=adl.spraddr_pidm and ad2.spraddr_status_ind is null and ad2.spraddr_atyp_code in ('MA')))
--       LEFT OUTER JOIN SPRADDR adh on (a.spriden_pidm=adh.spraddr_pidm and adh.spraddr_status_ind is null and concat(adh.spraddr_atyp_code,to_char(adh.spraddr_seqno,'009')) = (select max(CONCAT(ad2.spraddr_atyp_code,TO_CHAR(ad2.spraddr_seqno,'009'))) as maxcode from spraddr ad2 where ad2.spraddr_pidm=adh.spraddr_pidm and ad2.spraddr_status_ind is null and ad2.spraddr_atyp_code in ('PR')))
       left outer join sarappd ap2 on (a.spriden_pidm=ap2.sarappd_pidm and ts.sgbstdn_term_code_eff=ap2.sarappd_term_code_entry and ap2.sarappd_seq_no= (select max(ap3.sarappd_seq_no) as maxseq from sarappd ap3 where a.spriden_pidm=ap3.sarappd_pidm and ts.sgbstdn_term_code_eff=ap3.sarappd_term_code_entry and ap3.sarappd_term_code_entry >= :MinTerm.CODE and ap3.sarappd_term_code_entry <= :MaxTerm.CODE))
--       left outer join slrrasg ch on (a.spriden_pidm=ch.slrrasg_pidm and slrrasg_term_code=:MaxTerm.CODE and ch.slrrasg_ascd_code = 'AC')
        where
          a.spriden_change_ind is null
          and ts.sgbstdn_stst_code = 'AS'
--          and ts.sgbstdn_camp_code <> CASE WHEN :chkOL = 1 then 'OL' else '??' end
--          and (ts.sgbstdn_resd_code = 'F' OR p.spbpers_citz_code = 'N')
--          and ts.sgbstdn_styp_code IN ('T','F','C','U','N','D','G','R','X')                                 --:selSTYP.STYP_CODE
          and ts.sgbstdn_coll_code_1 <> 'SU'
          and ts.sgbstdn_majr_code_1 <> 'EHS'
          and ts.sgbstdn_term_code_eff =
          (select MAX(g.sgbstdn_term_code_eff) AS MAXTERM from sgbstdn g where g.sgbstdn_pidm=ts.sgbstdn_pidm and g.sgbstdn_term_code_eff <= :MaxTerm.CODE)
) WHERE
(DECCD IN ('AP','CF','CP','EN','QA') OR (DECCD='AX' AND styp_code in ('X','U','R')))
AND
(
(:chkI_Grad_R = 1 and CareerLevel = 'Grad' and Deccd <> 'EN' AND Registered = 'Yes')
OR
(:chkI_Grad_U = 1 and CareerLevel = 'Grad' and Deccd <> 'EN' AND Registered = 'No')
OR
(:chkI_UGrad_R = 1 and CareerLevel <> 'Grad' and Deccd <> 'EN' AND Registered = 'Yes')
OR
(:chkI_UGrad_U = 1 and CareerLevel <> 'Grad' and Deccd <> 'EN' AND Registered = 'No')
OR
(:chkC_Grad_R = 1 and CareerLevel = 'Grad' and Deccd = 'EN' AND Registered = 'Yes')
OR
(:chkC_Grad_U = 1 and CareerLevel = 'Grad' and Deccd = 'EN' AND Registered = 'No')
OR
(:chkC_UGrad_R = 1 and CareerLevel <> 'Grad' and Deccd = 'EN' AND Registered = 'Yes')
OR
(:chkC_UGrad_U = 1 and CareerLevel <> 'Grad' and Deccd = 'EN' AND Registered = 'No')
)
ORDER BY Last_Name, First_Name, SISID