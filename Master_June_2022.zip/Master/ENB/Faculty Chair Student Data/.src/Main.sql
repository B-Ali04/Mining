Select
    SPRIDEN.SPRIDEN_ID Banner_ID,
    f_format_name(SPRIDEN.SPRIDEN_PIDM, 'LFMI') Student_Name,
    SPBPERS.SPBPERS_PREF_FIRST_NAME Pref_First_Name,
    GOREMAL.GOREMAL_EMAIL_ADDRESS Email_Address,
    SPBPERS.SPBPERS_SEX Sex,
    STVCLAS.STVCLAS_DESC Student_Class,
    SGBSTDN.SGBSTDN_DEGC_CODE_1 Deg_Program,
    STVMAJR.STVMAJR_DESC Program_of_Study,
    STVDEPT.STVDEPT_DESC Dept_Desc,
    STVSTYP.STVSTYP_DESC Reg_Type,
    SGBSTDN.SGBSTDN_EXP_GRAD_DATE Exp_Grad_Date,
    case
        when SGRADVR.PIDM is null then ''
        else f_format_name(SGRADVR.ADVR_PIDM,'LF30')
    end as Advisor_Name,
    trunc(SHRTGPA.SHRTGPA_GPA,3) Semester_GPA,
    trunc(SHRLGPA.SHRLGPA_GPA,3) Cumulative_GPA,
    case
        when SPBPERS.SPBPERS_CITZ_CODE = 'Y' then 'United States'
        else (select STVNATN_NATION
        from STVNATN
        where STVNATN_CODE = nvl(GOBINTL_NATN_CODE_LEGAL,GOBINTL_NATN_CODE_BIRTH))
    end as Citz_Country,
    (select max(l.sfrstcr_term_code) from sfrstcr l where l.sfrstcr_pidm = spriden.spriden_pidm and l.sfrstcr_rsts_code = 'RE') as LastTerm

from
    SPRIDEN SPRIDEN

    join STVTERM STVTERM on STVTERM.STVTERM_CODE = :lb_Select_Term_Code.STVTERM_CODE

    join SPBPERS SPBPERS on SPBPERS.SPBPERS_PIDM = SPRIDEN.SPRIDEN_PIDM

    join SGBSTDN SGBSTDN on SGBSTDN.SGBSTDN_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SGBSTDN.SGBSTDN_TERM_CODE_EFF = fy_sgbstdn_eff_term(SGBSTDN.SGBSTDN_PIDM,STVTERM.STVTERM_CODE)
         and SGBSTDN.SGBSTDN_MAJR_CODE_1 not in ('0000', 'EHS', 'SUS', 'VIS')
         and SGBSTDN.SGBSTDN_STST_CODE = 'AS'
         and SGBSTDN.SGBSTDN_DEPT_CODE = 'EFB'

    left outer join GOREMAL GOREMAL on GOREMAL.GOREMAL_PIDM = SPRIDEN.SPRIDEN_PIDM
        and GOREMAL.GOREMAL_EMAL_CODE = 'SU'
        and GOREMAL.GOREMAL_STATUS_IND = 'A'

    left outer join SHRTGPA SHRTGPA on SHRTGPA.SHRTGPA_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SHRTGPA.SHRTGPA_TERM_CODE = STVTERM.STVTERM_CODE
        and SHRTGPA.SHRTGPA_GPA_TYPE_IND = 'I'

    left outer join SHRLGPA SHRLGPA on SHRLGPA.SHRLGPA_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRLGPA.SHRLGPA_LEVL_CODE = SGBSTDN.SGBSTDN_LEVL_CODE
         and SHRLGPA.SHRLGPA_GPA_TYPE_IND = 'I'

    left outer join GOBINTL GOBINTL on GOBINTL.GOBINTL_PIDM = SPRIDEN.SPRIDEN_PIDM

    left outer join rel_student_advisor SGRADVR on SGRADVR.PIDM = SPRIDEN.SPRIDEN_PIDM
        and SGRADVR.TERM_CODE = STVTERM.STVTERM_CODE
        and SGRADVR.primary_ind = 1
        and SGRADVR.PIDM like '%'

    join STVCLAS STVCLAS on STVCLAS.STVCLAS_CODE = f_class_calc_fnc(SGBSTDN.SGBSTDN_PIDM,SGBSTDN.SGBSTDN_LEVL_CODE, STVTERM.STVTERM_CODE)
    join STVMAJR STVMAJR on STVMAJR.STVMAJR_CODE = SGBSTDN.SGBSTDN_MAJR_CODE_1
    join STVDEPT STVDEPT on STVDEPT.STVDEPT_CODE = SGBSTDN.SGBSTDN_DEPT_CODE
    join STVSTYP STVSTYP on STVSTYP.STVSTYP_CODE = SGBSTDN.SGBSTDN_STYP_CODE

    where
    exists(
        select *
        from SFRSTCR SFRSTCR
        where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
        and SFRSTCR.SFRSTCR_RSTS_CODE in ('RE','RW'))
    and SPRIDEN.SPRIDEN_NTYP_CODE is null
    and SPRIDEN.SPRIDEN_CHANGE_IND is null

    and (
        (sgbstdn.sgbstdn_term_code_admit = STVTERM.STVTERM_CODE )
        or exists( select 1 from sfrstcr

       /* put variable here */

        where sfrstcr_term_code >= :SqlVariable1.PREV_TERM

        /*variable: formatted previous term*/
                   and sfrstcr_rsts_code = 'RE' and sfrstcr_pidm = SPRIDEN.SPRIDEN_PIDM))
        and not exists (select 1 from shrdgmr where shrdgmr_levl_code = SGBSTDN.SGBSTDN_LEVL_CODE
        and shrdgmr_pidm = SPRIDEN.SPRIDEN_PIDM
        and shrdgmr_degs_code = SGBSTDN.SGBSTDN_DEGC_CODE_1 )
--$addfilter
/*
    and exists(
        select *
        from SFRSTCR SFRSTCR
        where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
    )
    */
--$addfilter

--$beginorder

order by
    SPRIDEN.SPRIDEN_SEARCH_LAST_NAME

--$endorder
