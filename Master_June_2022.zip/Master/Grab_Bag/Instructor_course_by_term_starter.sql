select 
i.spriden_id,
i.spriden_last_name,
i.spriden_first_name,
SCBCRSE.SCBCRSE_TITLE Course_Title,
s.sirasgn_CRN,
SCBCRSE.SCBCRSE_ACTIVITY_DATE,
SCBCRSE.SCBCRSE_CIPC_CODE

from spriden i

join sirasgn s on s.sirasgn_pidm = i.spriden_pidm

    left outer join SSBSECT SSBSECT on SSBSECT.SSBSECT_CRN = s.sirasgn_CRN
        and SSBSECT.SSBSECT_TERM_CODE = s.sirasgn_term_code 
        
    left outer join SCBCRSE SCBCRSE on SSBSECT.SSBSECT_SUBJ_CODE = SCBCRSE.SCBCRSE_SUBJ_CODE
        and SCBCRSE.SCBCRSE_CRSE_NUMB = SSBSECT.SSBSECT_CRSE_NUMB
        and SCBCRSE.SCBCRSE_EFF_TERM = (select max(SCBCRSE_EFF_TERM)
                        from   SCBCRSE SCBCRSE1
                        where  SCBCRSE1.SCBCRSE_SUBJ_CODE = SSBSECT_SUBJ_CODE
                        and    SCBCRSE1.SCBCRSE_CRSE_NUMB = SSBSECT_CRSE_NUMB
                        and    SCBCRSE1.SCBCRSE_EFF_TERM <= s.sirasgn_term_code)
                        
where 
i.spriden_ntyp_code is null
and i.spriden_change_ind is null
and s.sirasgn_term_code  = 202240

order by spriden_search_last_name