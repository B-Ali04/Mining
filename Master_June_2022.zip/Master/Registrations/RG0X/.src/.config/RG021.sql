(
    SGBSTDN.SGBSTDN_STYP_CODE in ('T', 'F', 'U','C')

    and(
        not exists(
            select *

            from SFRSTCR SFRSTCR

            where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
            and SFRSTCR.SFRSTCR_RSTS_CODE = 'RE'
        )
    )
)

and 'N' = f_registered_this_term(SPRIDEN.SPRIDEN_PIDM, STVTERM.STVTERM_CODE)