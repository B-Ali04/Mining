SGBSTDN.SGBSTDN_STYP_CODE in ('F', 'C', 'T', 'U')

and SARAPPD.SARAPPD_SEQ_NO = (select max(SARAPPD_SEQ_NO)
                             from SARAPPD SARAPPDX
                             where SARAPPDX.SARAPPD_PIDM = SARAPPD.SARAPPD_PIDM
                             and SARAPPDX.SARAPPD_TERM_CODE_ENTRY = SARAPPD.SARAPPD_TERM_CODE_ENTRY)