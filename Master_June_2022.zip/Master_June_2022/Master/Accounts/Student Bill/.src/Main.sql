SELECT  TBRACCD_DETAIL_CODE AS DETAIL_CODE, TBBDETC_DESC AS DESCR,
        TBRACCD_AMOUNT AS AMOUNT, TBRACCD_TRANS_DATE AS TRANS_DATE
       ,case tbraccd_orig_chg_ind when 'Y' then tbraccd_amount else 0 end as ORIG
       ,case tbraccd_orig_chg_ind when 'Y' then 0 else
             case tbbdetc_type_ind when 'C' then tbraccd_amount else 0 end end as ADJUST
       ,case tbraccd_orig_chg_ind when 'Y' then 0 else
             case tbbdetc_type_ind when 'P' then tbraccd_amount else 0 end end as PAID
FROM TBRACCD, TBBDETC
WHERE TBRACCD_PIDM = :selBill.PIDM
AND   (TBRACCD_TERM_CODE = :selBill.TERM_CODE
OR     TBRACCD_TERM_CODE = :MainTerm)
AND TBBDETC_DETAIL_CODE=TBRACCD_DETAIL_CODE
ORDER BY TBRACCD_TRANS_DATE, TBRACCD_TRAN_NUMBER