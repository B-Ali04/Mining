-- REPORT CSV DETAILS AND FORMAT
Select

    -- ESF/SU ID DETAILS
    SPRIDEN.SPRIDEN_ID Banner_ID,
    f_format_name(SPRIDEN.SPRIDEN_PIDM, 'LFMI') Student_Name,
    GORADID.GORADID_ADDITIONAL_ID SU_ID,

    -- ADVISEMENT DETAILS
    STVCLAS.STVCLAS_CODE Student_Class,
    SGBSTDN.SGBSTDN_DEGC_CODE_1 Degree_Program,
    SGBSTDN.SGBSTDN_TERM_CODE_EFF Semester,
    STVSTYP.STVSTYP_DESC Student_Type,

    -- TERM GPA DETAILS
    SHRTGPA.SHRTGPA_HOURS_ATTEMPTED Semester_HC,
    SHRTGPA.SHRTGPA_GPA_HOURS Semester_HP,
    SHRTGPA.SHRTGPA_QUALITY_POINTS Semester_Grd_Pts,
    trunc(SHRTGPA.SHRTGPA_GPA,3) Semester_GPA,

    -- SEMESTER GPA DETAILS
    SHRLGPA.SHRLGPA_HOURS_ATTEMPTED Cumulative_HC,
    SHRLGPA.SHRLGPA_GPA_HOURS Cumulative_HP,
    SHRLGPA.SHRLGPA_QUALITY_POINTS Cumulative_Grd_Pts,
    trunc(SHRLGPA.SHRLGPA_GPA,3) Cumulative_GPA,

    -- PERMANENT ADDRESS DETAILS
    SPRADDR.SPRADDR_STREET_LINE1 Permanent_Street_1,
    SPRADDR.SPRADDR_STREET_LINE2 Permanent_Street_2,
    SPRADDR.SPRADDR_CITY Permanent_City,
    SPRADDR.SPRADDR_STAT_CODE Permanent_State,
    substr(SPRADDR.SPRADDR_ZIP,1,5) Perm_Zip_Code,

    -- MAILING ADDRESS DETAILS
    SPRADDR1.SPRADDR_STREET_LINE1 Mailing_Street_1,
    SPRADDR1.SPRADDR_STREET_LINE2 Mailing_Street_2,
    SPRADDR1.SPRADDR_CITY Mailing_City,
    SPRADDR1.SPRADDR_STAT_CODE Mailing_State,
    substr(SPRADDR1.SPRADDR_ZIP,1,5) Mailing_Zip_Code,

    -- CONTACT INFORMATION
    GOREMAL.GOREMAL_EMAIL_ADDRESS Email,

    --SORTING FIELDS
    SPRIDEN.SPRIDEN_SEARCH_LAST_NAME,
    STVCLAS.STVCLAS_SURROGATE_ID,
    STVSTYP.STVSTYP_SURROGATE_ID

-- SOURCES
from

    -- IDENTIFICATION
    SPRIDEN SPRIDEN

    left outer join GORADID GORADID on GORADID.GORADID_PIDM = SPRIDEN.SPRIDEN_PIDM
         and GORADID.GORADID_ADID_CODE = 'SUID'

    -- EMAIL
    left outer join GOREMAL GOREMAL on GOREMAL.GOREMAL_PIDM = SPRIDEN.SPRIDEN_PIDM
         and GOREMAL.GOREMAL_EMAL_CODE = 'SU'

    -- PREFFERED ADDRESSES
    left outer join SPRADDR SPRADDR on SPRADDR.SPRADDR_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SPRADDR.SPRADDR_ATYP_CODE in ('PR')
        and SPRADDR.SPRADDR_STATUS_IND is null
        and SPRADDR_STREET_LINE1 is not null
        and SPRADDR.SPRADDR_VERSION = (
             select max(SPRADDR_VERSION)
             from SPRADDR SPRADDRX
             where SPRADDRX.SPRADDR_PIDM = SPRADDR.SPRADDR_PIDM
             and SPRADDRX.SPRADDR_ATYP_CODE in ('PR')
             and SPRADDRX.SPRADDR_STATUS_IND is null)
        and SPRADDR.SPRADDR_SURROGATE_ID = (
             select max(SPRADDR_SURROGATE_ID)
             from SPRADDR SPRADDRX
             where SPRADDRX.SPRADDR_PIDM = SPRADDR.SPRADDR_PIDM
             and SPRADDRX.SPRADDR_ATYP_CODE in ('PR')
             and SPRADDRX.SPRADDR_STATUS_IND is null)

    left outer join SPRADDR SPRADDR1 on SPRADDR1.SPRADDR_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SPRADDR1.SPRADDR_ATYP_CODE in ('MA')
        and SPRADDR1.SPRADDR_STATUS_IND is null
        and SPRADDR1.SPRADDR_STREET_LINE1 is not null
        and SPRADDR1.SPRADDR_VERSION = (select max(SPRADDR_VERSION)
                                       from SPRADDR SPRADDRX
                                       where SPRADDRX.SPRADDR_PIDM = SPRADDR1.SPRADDR_PIDM
                                       and SPRADDRX.SPRADDR_ATYP_CODE in ('MA')
                                       and SPRADDRX.SPRADDR_STATUS_IND is null
                                           )
        and SPRADDR1.SPRADDR_SURROGATE_ID = (select max(SPRADDR_SURROGATE_ID)
                                            from SPRADDR SPRADDRX
                                            where SPRADDRX.SPRADDR_PIDM = SPRADDR1.SPRADDR_PIDM
                                            and SPRADDRX.SPRADDR_ATYP_CODE in ('MA')
                                            and SPRADDRX.SPRADDR_STATUS_IND is null
                                                )

    -- TERM SELECTION
    join STVTERM STVTERM on STVTERM.STVTERM_CODE = :parm_term_code_select.STVTERM_CODE

    -- STUDENT DATA
    left outer join SGBSTDN SGBSTDN on SGBSTDN.SGBSTDN_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SGBSTDN.SGBSTDN_LEVL_CODE = 'UG'
         and SGBSTDN.SGBSTDN_MAJR_CODE_1 not in ('0000', 'EHS', 'SUS', 'VIS')
         and SGBSTDN.SGBSTDN_TERM_CODE_EFF = fy_sgbstdn_eff_term(SGBSTDN.SGBSTDN_PIDM, STVTERM.STVTERM_CODE)

    -- TERM GPA DATA
    left outer join SHRTGPA SHRTGPA on SHRTGPA.SHRTGPA_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRTGPA.SHRTGPA_TERM_CODE = STVTERM.STVTERM_CODE
         and SHRTGPA.SHRTGPA_GPA_TYPE_IND = 'I'

    -- CUMMULATIVE GPA DATA
    left outer join SHRLGPA SHRLGPA on SHRLGPA.SHRLGPA_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRLGPA.SHRLGPA_LEVL_CODE = SGBSTDN.SGBSTDN_LEVL_CODE
         and SHRLGPA.SHRLGPA_GPA_TYPE_IND = 'I'
         and SHRLGPA.SHRLGPA_GPA is not null

    -- ACADEMIC STANDARDS
    left outer join SHRTTRM SHRTTRM on SHRTTRM.SHRTTRM_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRTTRM.SHRTTRM_TERM_CODE = (select max(SHRTTRM_TERM_CODE)
                                         from SHRTTRM SHRTTRMX
                                         where SHRTTRMX.SHRTTRM_PIDM = SPRIDEN.SPRIDEN_PIDM
                                         and SHRTTRMX.SHRTTRM_TERM_CODE < STVTERM.STVTERM_CODE)

    -- ADDITIONAL INFORMATION
    left outer join STVDEPT STVDEPT on STVDEPT.STVDEPT_CODE = SGBSTDN.SGBSTDN_DEPT_CODE

    left outer join STVSTYP STVSTYP on STVSTYP.STVSTYP_CODE = SGBSTDN.SGBSTDN_STYP_CODE

    left outer join STVDEGC STVDEGC on STVDEGC.STVDEGC_CODE = SGBSTDN.SGBSTDN_DEGC_CODE_1

    left outer join STVMAJR STVMAJR on STVMAJR.STVMAJR_CODE = SGBSTDN.SGBSTDN_MAJR_CODE_1

    left outer join STVCLAS STVCLAS on STVCLAS.STVCLAS_CODE = f_class_calc_fnc(SGBSTDN.SGBSTDN_PIDM,SGBSTDN.SGBSTDN_LEVL_CODE, STVTERM.STVTERM_CODE)

-- CONDITIONS
where
    SPRIDEN.SPRIDEN_NTYP_CODE is null
    and SPRIDEN.SPRIDEN_CHANGE_IND is null

    -- ACTIVE_REGISTRATION: SGASTDN RECORD SHOWS *NOT WITHDRAWN* FROM EFFECTIVE BANNER TERM; STUDENT HAS ENROLLED
    and(
        not exists(
            select *
            from SFRWDRL SFRWDRL
            where SFRWDRL.SFRWDRL_PIDM = SPRIDEN.SPRIDEN_PIDM
            and SFRWDRL.SFRWDRL_TERM_CODE = SGBSTDN.SGBSTDN_TERM_CODE_EFF
            )

        and 'Y' = f_registered_this_term(SPRIDEN.SPRIDEN_PIDM, STVTERM.STVTERM_CODE)
        )

--$addfilter

--$beginorder

-- GROUPING/ORDERING
order by
    STVSTYP.STVSTYP_SURROGATE_ID, STVCLAS.STVCLAS_SURROGATE_ID, SPRIDEN.SPRIDEN_SEARCH_LAST_NAME

--$endorder