SFRSTCR.SFRSTCR_GRDE_CODE = :parm_grade_code_select.GRADECODE
    and (
         exists(

         select *

         from SFRSTCR r

         where r.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
               and r.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
               and r.SFRSTCR_RSTS_CODE like 'R%'
               
            )
            --and SGBSTDN.SGBSTDN_MAJR_CODE_1 not in ('EHS', 'SUS','0000','VIS')
        )

SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE

order by
    SPRIDEN.SPRIDEN_LAST_NAME, SPRIDEN.SPRIDEN_FIRST_NAME 