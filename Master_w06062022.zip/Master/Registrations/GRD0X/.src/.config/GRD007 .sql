SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
and SFRSTCR.SFRSTCR_GRDE_CODE in ('IF','I')
and SHRTCKG.SHRTCKG_GRDE_CODE_FINAL = SFRSTCR.SFRSTCR_GRDE_CODE-- for review
-- 

order by
    SPRIDEN.SPRIDEN_LAST_NAME, SPRIDEN.SPRIDEN_FIRST_NAME, SSBSECT.SSBSECT_SUBJ_CODE, SSBSECT.SSBSECT_CRSE_NUMB
/*

    and (SFRSTCR.SFRSTCR_GRDE_CODE in ('IF','I')
        and not exists(select * from SHRTCKG 
                      where SHRTCKG.SHRTCKG_PIDM = SFRSTCR.SFRSTCR_PIDM
                      and SHRTCKG.SHRTCKG_TERM_CODE = SHRTCKN.SHRTCKN_TERM_CODE
                      and SHRTCKG.SHRTCKG_TCKN_SEQ_NO = SHRTCKN.SHRTCKN_SEQ_NO         
                      and SHRTCKG.SHRTCKG_SEQ_NO = (select max(SHRTCKG_SEQ_NO)
                                                   from SHRTCKG SHRTCKNX
                                                   where SHRTCKNX.SHRTCKG_TERM_CODE = SHRTCKG.SHRTCKG_TERM_CODE
                                                   and SHRTCKNX.SHRTCKG_TCKN_SEQ_NO = SHRTCKG.SHRTCKG_TCKN_SEQ_NO )
                                                   ))
                                                   */