select * from (
SELECT SPRIDEN_ID AS BANNERID
       , su.goradid_additional_id as SUID
       , SPRIDEN_LAST_NAME, SPRIDEN_FIRST_NAME
       , ORIG_CHG, ADJUSTMENTS, PAYMENTS
       , (ORIG_CHG + ADJUSTMENTS - PAYMENTS) AS NET_AMT
      , sgbstdn.sgbstdn_levl_code as Levl
      , sgbstdn.sgbstdn_term_code_admit as admit_term
      , sgbstdn.sgbstdn_term_code_eff   as eff_term
      , :MaxTerm.STVTERM_CODE AS MAXTERM
      , SPRIDEN_PIDM AS PIDM
FROM
(SELECT
PIDM, SUM(ORIG_CHG) AS ORIG_CHG, SUM(ADJUSTMENTS) AS ADJUSTMENTS, SUM(PAYMENTS) AS PAYMENTS, SUM(BAL) AS BAL
--, SUM(AUTHORIZE_AMT) AS AUTHORIZE_AMT
FROM(
--SELECT
--      RPRAWRD_PIDM as PIDM,
--      SUM(RPRAWRD_AUTHORIZE_AMT-RPRAWRD_AUTHORIZE_AMT) AS ORIG_CHG,
--      SUM(RPRAWRD_AUTHORIZE_AMT-RPRAWRD_AUTHORIZE_AMT) AS ADJUSTMENTS,
--      SUM(RPRAWRD_AUTHORIZE_AMT-RPRAWRD_AUTHORIZE_AMT) AS PAYMENTS,
--      SUM(RPRAWRD_AUTHORIZE_AMT-RPRAWRD_AUTHORIZE_AMT) AS BAL,
--      SUM(RPRAWRD_AUTHORIZE_AMT) AS AUTHORIZE_AMT
--      FROM RPRAWRD
--         WHERE RPRAWRD_AIDY_CODE=:selAIDY.CODE
--         and rprawrd_authorize_amt is not null
--      GROUP BY RPRAWRD_PIDM
--UNION
     SELECT PIDM, SUM(ORIG_CHG) AS ORIG_CHG, SUM(ADJUSTMENTS) AS ADJUSTMENTS, SUM(PAYMENTS) AS PAYMENTS, SUM(BAL) AS BAL
--     , SUM(AUTHORIZE_AMT) AS AUTHORIZE_AMT
     FROM
     (select tbraccd_pidm AS PIDM
             ,case tbraccd_orig_chg_ind when 'Y' then tbraccd_amount else 0 end as ORIG_CHG
             ,case tbraccd_orig_chg_ind when 'Y' then 0 else
             case tbbdetc_type_ind when 'C' then tbraccd_amount else 0 end end as ADJUSTMENTS
             ,case tbraccd_orig_chg_ind when 'Y' then 0 else
             case tbbdetc_type_ind when 'P' then tbraccd_amount else 0 end end as PAYMENTS
             ,CASE tbbdetc_type_ind when 'C' then tbraccd_balance else -tbraccd_balance end AS BAL
             ,(TBRACCD_AMOUNT-TBRACCD_AMOUNT) as AUTHORIZE_AMT
      from tbraccd
      LEFT OUTER JOIN TBBDETC ON (tbraccd_detail_code = tbbdetc_detail_code)
      WHERE tbraccd_term_code >= :MinTerm.STVTERM_CODE
        and tbraccd_term_code <= :MaxTerm.STVTERM_CODE
         )
      GROUP BY PIDM
)
GROUP BY PIDM)
INNER JOIN SPRIDEN ON (SPRIDEN_PIDM=PIDM)
INNER JOIN SPBPERS ON (SPRIDEN_PIDM=SPBPERS_PIDM)
INNER JOIN SGBSTDN ON (SPRIDEN_PIDM=SGBSTDN_PIDM AND SGBSTDN_TERM_CODE_EFF=(SELECT MAX(b.SGBSTDN_TERM_CODE_EFF) FROM SGBSTDN b where spriden.spriden_pidm=b.sgbstdn_pidm))
LEFT OUTER JOIN GORADID su ON (SPRIDEN_PIDM=GORADID_PIDM AND GORADID_ADID_CODE='SUID')
WHERE SPRIDEN_CHANGE_IND IS NULL
and sgbstdn_coll_code_1 <> 'SU'
AND SGBSTDN_MAJR_CODE_1 <> 'EHS'
--and (case when :chkExclGrads = 1 then
--          case when sgbstdn.sgbstdn_levl_code = 'GR' THEN 0 ELSE 1 end
--    else 1
--    end) = 1
--AND (ORIG_CHG + ADJUSTMENTS - PAYMENTS) > TO_NUMBER(:edtAmount)
--AND (BAL) > TO_NUMBER(:edtAmount)
--and BAL <> 0
--AND PIDM NOT IN (SELECT DISTINCT SPRHOLD_PIDM FROM SPRHOLD WHERE SPRHOLD_HLDD_CODE='PP' AND SPRHOLD_TO_DATE > SYSDATE)
--AND PIDM NOT IN (SELECT DISTINCT SGRSATT_PIDM FROM SGRSATT WHERE SGRSATT_ATTS_CODE='VAB' AND ((SGRSATT_TERM_CODE_EFF >= :MinTerm.STVTERM_CODE AND SGRSATT_TERM_CODE_EFF <= :MaxTerm.STVTERM_CODE) OR (SGRSATT_TERM_CODE_EFF < :MinTerm.STVTERM_CODE AND SGRSATT_END_TERM_ETHOS='999999')))
--AND PIDM NOT IN (SELECT DISTINCT SGRCHRT_PIDM FROM SGRCHRT WHERE SGRCHRT_CHRT_CODE='VAB' AND ((SGRCHRT_TERM_CODE_EFF >= :MinTerm.STVTERM_CODE AND SGRCHRT_TERM_CODE_EFF <= :MaxTerm.STVTERM_CODE) OR (SGRCHRT_TERM_CODE_EFF < :MinTerm.STVTERM_CODE AND SGRCHRT_END_TERM_ETHOS='999999')))
ORDER BY SPRIDEN_LAST_NAME, SPRIDEN_FIRST_NAME, SPRIDEN_ID
)
WHERE NET_AMT <> 0
ORDER BY NET_AMT DESC
--where mintuit is not null
--and mintuit <= :datTuit