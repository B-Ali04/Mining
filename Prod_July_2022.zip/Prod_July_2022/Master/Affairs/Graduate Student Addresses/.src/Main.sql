select r.pidm, r.id as BannerID,
       r.fname,
       r.lname,
       r.mname,
       r.pref_fname,
       spbpers.spbpers_pref_first_name,
       case
         when spbpers.spbpers_gndr_code is not null
           then (select gtvgndr_gndr_desc from gtvgndr where gtvgndr_gndr_code = spbpers.spbpers_gndr_code)
         when spbpers.spbpers_sex = 'F' then 'Female'
         when spbpers.spbpers_sex = 'M' then 'Male'
         else spbpers.spbpers_sex
       end as GenderDesignation,
       case
         when spbpers.spbpers_pprn_code is not null
           then (select gtvpprn_pprn_desc from gtvpprn where gtvpprn_pprn_code = spbpers.spbpers_pprn_code)
         else ''
       end as PronounDesignation,
       case
        when spbpers_ethn_cde = 2 then 1
        else coalesce((select 1 from rel_race rac where r.pidm = rac.pidm and rac.race_code = '40'),0)
    end as RaceHisp,
    coalesce((select 1 from rel_race rac where r.pidm = rac.pidm and rac.race_code = '70'),0) as RaceWhite,
    coalesce((select 1 from rel_race rac where r.pidm = rac.pidm and rac.race_code = '30'),0) as RaceBlack,
    coalesce((select 1 from rel_race rac where r.pidm = rac.pidm and rac.race_code = '20'),0) as RaceAsian,
    coalesce((select 1 from rel_race rac where r.pidm = rac.pidm and rac.race_code = '50'),0) as RaceHaw,
    coalesce((select 1 from rel_race rac where r.pidm = rac.pidm and rac.race_code = '10'),0) as RaceNative,
    case
        when exists (select * from rel_race rac where r.pidm = rac.pidm) then 0
        else 1
    end as RaceUnk,
       spbpers.spbpers_birth_date as DOB,
       suid.goradid_additional_id as SUID,
       spbpers_confid_ind as Confidential,
       (select t.sprtele_phone_area || '-' || t.sprtele_phone_number from sprtele t where t.sprtele_pidm = r.pidm and t.sprtele_tele_code = 'PA' and t.sprtele_seqno = (select max(tPA.sprtele_seqno) from sprtele tPA where tPA.Sprtele_Tele_Code = t.sprtele_tele_code and t.sprtele_pidm = tPA.Sprtele_Pidm)) as PAPhone,
       (select t.sprtele_phone_area || '-' || t.sprtele_phone_number from sprtele t where t.sprtele_pidm = r.pidm and t.sprtele_tele_code = 'P2' and t.sprtele_seqno = (select max(tPA.sprtele_seqno) from sprtele tPA where tPA.Sprtele_Tele_Code = t.sprtele_tele_code and t.sprtele_pidm = tPA.Sprtele_Pidm)) as P2Phone,
       (select t.sprtele_phone_area || '-' || t.sprtele_phone_number from sprtele t where t.sprtele_pidm = r.pidm and t.sprtele_tele_code = 'PC' and t.sprtele_seqno = (select max(tPA.sprtele_seqno) from sprtele tPA where tPA.Sprtele_Tele_Code = t.sprtele_tele_code and t.sprtele_pidm = tPA.Sprtele_Pidm)) as PCPhone,
       (select t.sprtele_phone_area || '-' || t.sprtele_phone_number from sprtele t where t.sprtele_pidm = r.pidm and t.sprtele_tele_code = 'PR' and t.sprtele_seqno = (select max(tPA.sprtele_seqno) from sprtele tPA where tPA.Sprtele_Tele_Code = t.sprtele_tele_code and t.sprtele_pidm = tPA.Sprtele_Pidm)) as PRPhone,
    GOREMAL.GOREMAL_email_address as "Email",
    d.degc_code, d.degc_desc as DegreeDesc,
    majr.stvmajr_desc as Major1,
    conc.stvmajr_desc as ConcentrationMajor1,
    majr2.stvmajr_desc as Major2,
    conc2.stvmajr_desc as ConcentrationMajor2,
    minr.stvmajr_desc as Minor,
    minr2.stvmajr_desc as Minor2,
    dgmr.*,
    a.*
from
    rel_identity_student r
    inner join rel_student_degree d on d.pidm = r.pidm
    inner join shrdgmr dgmr on dgmr.shrdgmr_pidm = r.pidm and dgmr.shrdgmr_seq_no = d.seq_no and dgmr.shrdgmr_levl_code = d.levl_code
    left outer join rel_address a on a.pidm = r.pidm and a.active_ind = 1 and (a.end_date > sysdate or a.end_date is null) and a.atyp_code = :lbATyp.STVATYP_CODE
    left outer join GORADID suid on suid.goradid_pidm = r.PIDM and suid.goradid_adid_code = 'SUID'
    left outer join GOREMAL GOREMAL on GOREMAL.GOREMAL_PIDM = r.PIDM
        and GOREMAL.GOREMAL_PREFERRED_IND = 'Y'
    left outer join SPBPERS SPBPERS on SPBPERS.SPBPERS_PIDM = r.PIDM
    left outer join STVMAJR majr on majr.STVMAJR_CODE = dgmr.shrdgmr_majr_code_1
    left outer join STVMAJR majr2 on majr2.STVMAJR_CODE = dgmr.shrdgmr_majr_code_2
    left outer join STVMAJR conc on conc.STVMAJR_CODE = dgmr.shrdgmr_majr_code_conc_1
    left outer join STVMAJR conc2 on conc2.STVMAJR_CODE = dgmr.shrdgmr_majr_code_conc_2
    left outer join STVMAJR minr on minr.STVMAJR_CODE = dgmr.shrdgmr_majr_code_minr_1
    left outer join STVMAJR minr2 on minr.STVMAJR_CODE = dgmr.shrdgmr_majr_code_minr_1_2
where
    d.grad_date = :lbGradDate.GRAD_DATE
    --$addfilter
--$beginorder
order by
    upper(r.lname)
--$endorder