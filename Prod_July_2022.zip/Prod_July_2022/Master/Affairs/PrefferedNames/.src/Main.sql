     select DISTINCT a.spriden_id as BannerID, a.spriden_pidm as PIDM, a.spriden_last_name as Last_Name, a.spriden_first_name as First_Name,
       CASE when p.spbpers_pref_first_name is not null then p.spbpers_pref_first_name else ' ' end as Pref_Name,
--       c.gobumap_udc_id as UDCID, d.gobtpac_external_user as ESFiD,
       b1.goradid_additional_id as SUID,
--       b2.goradid_additional_id as SU_NETID,
       case when b2.goradid_pidm is not null then concat(b2.goradid_additional_id,'@syr.edu') else e.goremal_email_address end as SU_EMAIL,
       ts.sgbstdn_styp_code AS Student_Type,
       ts.sgbstdn_stst_code as Student_Status,
       case when ts.sgbstdn_styp_code in ('T','F','C','U') then 'UnderGrad' when ts.sgbstdn_styp_code in ('N','D','G','R') then 'Grad' else 'Other' end as Type,
       ts.sgbstdn_term_code_admit as Admit_Term,
       ts.sgbstdn_camp_code as Campus,
       p.spbpers_activity_date as last_activity
--       ,s2.spriden_id as RECID

--       a.spriden_origin as origin,
--       a.spriden_create_date as create_date
--       , a.*
       from spriden a
       INNER JOIN sgbstdn ts on (ts.sgbstdn_pidm=a.spriden_pidm)
       INNER JOIN spbpers p on (a.spriden_pidm=spbpers_pidm)
       LEFT OUTER JOIN goradid b1 on (b1.goradid_pidm=a.spriden_pidm and b1.goradid_adid_code='SUID')
       LEFT OUTER JOIN goradid b2 on (b2.goradid_pidm=a.spriden_pidm and b2.goradid_adid_code='SUNI')
--       LEFT OUTER JOIN gobumap c on (c.gobumap_pidm=a.spriden_pidm)
--       LEFT OUTER JOIN gobtpac d on (d.gobtpac_pidm=a.spriden_pidm)
       LEFT OUTER JOIN GOREMAL e on (a.spriden_pidm=e.goremal_pidm and e.goremal_emal_code='SU')
       left outer join spriden s2 on (a.spriden_pidm=s2.spriden_pidm and s2.spriden_ntyp_code='LGCY')
        where
          a.spriden_change_ind is null
--          and d.gobtpac_external_user is not null
--          and c.gobumap_udc_id is not null
--          and b1.goradid_additional_id is not null
--          and ts.sgbstdn_styp_code <> 'X'

--          and ((ts.sgbstdn_term_code_eff < '202130' and ts.sgbstdn_pidm in (select sfrstcr_pidm from sfrstcr where sfrstcr_rsts_code = 'RE'))
--          OR ts.sgbstdn_term_code_eff in ('202130','202140'))
          and ts.sgbstdn_stst_code = 'AS'
          and ts.sgbstdn_coll_code_1 <> 'SU'
          AND ts.sgbstdn_majr_code_1 <> 'EHS'
          and ts.sgbstdn_term_code_eff =
          (select MAX(g.sgbstdn_term_code_eff) AS MAXTERM from sgbstdn g where g.sgbstdn_pidm=ts.sgbstdn_pidm and g.sgbstdn_term_code_eff <= :MaxTerm.CODE)
          and a.spriden_pidm in (select distinct pn.spbpers_pidm from spbpers pn where pn.spbpers_pref_first_name is not null and pn.spbpers_activity_date >= :datSince)
          and ts.sgbstdn_term_code_eff <= :MaxTerm.CODE
          and ts.sgbstdn_styp_code = :selSTYP.STYP_CODE

--          and a.spriden_pidm in (select distinct sfrstcr_pidm FROM SFRSTCR where sfrstcr_term_code in ('202130','202140') and sfrstcr_rsts_code = 'RE')
--          and b2.goradid_additional_id is null
--          and (spriden_id= Upper(:OptionValue) or spriden_search_last_name= Upper(:OptionValue))
order by a.spriden_last_name, a.spriden_first_name, a.spriden_id