select clas.stvclas_desc, stdn.sgbstdn_term_code_eff, iden.* from spriden iden

join stvterm term on term.stvterm_code = 202320

left outer join sgbstdn stdn on stdn.sgbstdn_pidm = iden.spriden_pidm
     and stdn.sgbstdn_stst_code = 'AS'

join stvclas clas on clas.stvclas_code = f_class_calc_fnc(iden.spriden_PIDM,STDN.SGBSTDN_LEVL_CODE, stdn.sgbstdn_term_code_eff)
where
     iden.spriden_ntyp_code is null
     and iden.spriden_change_ind is null
     --and clas.stvclas_code = 'SR'
     --and stdn.sgbstdn_term_code_eff >= (term.stvterm_code-500)     
                                                   
order by --stdn.sgbstdn_dept_code, 
      iden.spriden_search_last_name, iden.spriden_search_first_name, sgbstdn_Term_code_eff desc

      fivepresent