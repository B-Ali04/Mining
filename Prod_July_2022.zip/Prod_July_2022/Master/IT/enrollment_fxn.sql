and(
    not exists(
        select * 
        from SFRWDRL SFRWDRL
        where SFRWDRL.SFRWDRL_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SFRWDRL.SFRWDRL_TERM_CODE = SGBSTDN.SGBSTDN_TERM_CODE_EFF
    )

    and 'Y' = f_registered_this_term(SPRIDEN.SPRIDEN_PIDM, STVTERM.STVTERM_CODE)
)

and(
        SHRTCKG.SHRTCKG_GRDE_CODE_FINAL in(
            select SHRTCKG.SHRTCKG_GRDE_CODE_FINAL
            from SHRTCKG SHRTCKG
            where SHRTCKG.SHRTCKG_PIDM = SPRIDEN.SPRIDEN_PIDM
            and SHRTCKG.SHRTCKG_TERM_CODE = SHRTCKN.SHRTCKN_TERM_CODE
            and SHRTCKG.SHRTCKG_GRDE_CODE_FINAL in ('U', 'I')
            group by SHRTCKG.SHRTCKG_GRDE_CODE_FINAL
            have count(*)>1
        )
    )