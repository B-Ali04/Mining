select
      case
          when i.pref_fname <> i.fname then i.pref_fname
          else null
      end as pref_fname, i.fname, i.lname,i.mname,i.id, a.advr_desc, a.advr_lname, suid.goradid_additional_id as SUID, em.goremal_email_address as SUEmail
from rel_identity_student i
inner join rel_student_advisor a on a.pidm = i.pidm and a.term_code = :ddSemester.STVTERM_CODE
left outer join goradid suid on suid.goradid_pidm = i.pidm and suid.goradid_adid_code = 'SUID'
left outer join goremal em on em.goremal_pidm = i.pidm and em.goremal_emal_code = 'SU'
where a.advr_pidm = :ddAdvisor.ADVRPIDM
and exists (select * from sfrstcr r where r.sfrstcr_term_code = a.term_code and r.sfrstcr_pidm = i.pidm and r.sfrstcr_rsts_code = 'RE')
--$addfilter
--$beginorder
order by
    i.lname, i.fname
--$endorder