select
    s.id,
    s.lname || ', ' || coalesce(s.pref_fname, s.fname) || ' ' || s.mname as StudentName,
    s.pref_fname,
    s.fname,
    s.mname,
    s.lname,
    e.email,
    reg.sfrstcr_credit_hr,
    reg.sfrstcr_rsts_code,
    cs.crn, cs.subj_code,
    cs.crse_numb,
    cs.seq_numb,
    cs.crse_title,
    ci.lfmi_name as PrimaryInstrName,
    g.sgbstdn_majr_code_1 as ProgramofStudy
from
    rel_course_sections cs
  left outer join rel_course_instructors ci on ci.term_code = cs.term_code and ci.crn = cs.crn and ci.primary_ind = 'Y'
  inner join sfrstcr reg
      on reg.sfrstcr_term_code = cs.term_code
      and cs.crn = reg.sfrstcr_crn
  inner join rel_identity_student s
      on s.pidm = reg.sfrstcr_pidm
  inner join sgbstdn g
      on g.sgbstdn_pidm = s.pidm
      and g.sgbstdn_term_code_eff = fy_sgbstdn_eff_term(s.pidm, cs.term_code)
  left outer join rel_email e
      on e.pidm = s.pidm
      and e.emal_code = 'SU'
where
    cs.dept_code = :ddDept.STVDEPT_CODE
and cs.term_code = :ddSemester.STVTERM_CODE
and ('-All-' = :ddSubj.SUBJ_CODE
  or ('-All-' <> :ddSubj.SUBJ_CODE
    and cs.subj_code = :ddSubj.SUBJ_CODE))
and ('-All-' = :ddCrse.CRSE_NUMB
  or ('-All-' <> :ddCrse.CRSE_NUMB
    and cs.crse_numb = :ddCrse.CRSE_NUMB))
and reg.sfrstcr_rsts_code = 'RE'
order by
    cs.subj_code,
    cs.crse_numb,
    cs.seq_numb,
    s.lname,
    s.fname
