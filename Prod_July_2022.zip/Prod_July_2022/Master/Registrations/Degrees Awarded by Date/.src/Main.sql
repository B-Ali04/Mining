select i.pidm,
    case
       when i.pref_fname is not null and i.pref_fname <> i.fname
          then i.lname || ', ' || i.fname || ' (' || i.pref_fname || ')'
       else
           i.lfmi_name
       end as "Student",
    suid.goradid_additional_id as SUID,
    d.*,
    dgmr.*,
    i.gender

from
    rel_identity_student i
    inner join rel_student_degree d on d.pidm = i.pidm
    inner join shrdgmr dgmr on dgmr.shrdgmr_pidm = i.pidm and dgmr.shrdgmr_seq_no = d.seq_no and dgmr.shrdgmr_levl_code = d.levl_code
    left outer join GORADID suid on suid.goradid_pidm = i.PIDM and suid.goradid_adid_code = 'SUID'
where
    d.grad_date = :lbGradDate.GRAD_DATE
    and d.degc_code = :lbDegLvl.DEGC_CODE
    --$addfilter
--$beginorder
order by
    d.grad_date desc,
    i.lname, i.fname, d.seq_no
--$endorder