-- REPORT FORMAT

Select

    -- ESF/SU ID DETAILS
    SPRIDEN.SPRIDEN_ID BANNER_ID,
    SPRIDEN.SPRIDEN_FIRST_NAME First_Name,
    SPRIDEN.SPRIDEN_LAST_NAME Last_Name,
    f_format_name(SPRIDEN_PIDM, 'LFMI') Full_Name,
    GORADID.GORADID_ADDITIONAL_ID SUID,

    -- ADVISEMENT/ DEGREE DETAILS
    SHRDGMR.SHRDGMR_LEVL_CODE Student_Level,
    --STVCLAS.STVCLAS_DESC Student_Class,
    STVDEGC.STVDEGC_CODE Degree_Program,
    STVMAJR.STVMAJR_DESC Major_Program,
    STVMAJR2.STVMAJR_DESC Minor_Program,
    STVMAJR3.STVMAJR_DESC Minor_Program_2,
    STVMAJR4.STVMAJR_DESC Conc_Program,

    -- DEGREE DETAILS/SUPERLATIVES/ACADEMIC STANDING
    --- Inclusive bounds, numeric GPA added ACK 6/13/22
    case
      when SHRDGMR.SHRDGMR_LEVL_CODE = 'UG' and ((SHRLGPA.SHRLGPA_GPA >= 3.0) and (SHRLGPA.SHRLGPA_GPA < 3.334)) then 'Cum Laude'
      when SHRDGMR.SHRDGMR_LEVL_CODE = 'UG' and ((SHRLGPA.SHRLGPA_GPA >= 3.334) and (SHRLGPA.SHRLGPA_GPA < 3.830)) then 'Magna Cum Laude'
      when SHRDGMR.SHRDGMR_LEVL_CODE = 'UG' and ((SHRLGPA.SHRLGPA_GPA >= 3.830)) then 'Summa Cum Laude'
        else ''
    end Academic_Honors_Calc,
    SHRLGPA.SHRLGPA_GPA as CumulativeGPA,
    STVHONR.STVHONR_DESC Academic_Honors_Posted,
    SHRDGIH.SHRDGIH_ACTIVITY_DATE Post_Date,

    case
         when SHRTTRM.SHRTTRM_ASTD_CODE_DL = 'DL' then 'Deans List'
         when SHRTTRM.SHRTTRM_ASTD_CODE_DL in ('PL') then 'Presidents List'
         when SHRTTRM.SHRTTRM_ASTD_CODE_DL in ('PR') then 'Presidents List (4.000 List)'
           else ''
    end as Deans_List,
    STVHOND.STVHOND_DESC Departmental_Honors,
    case
        when SGRSATT.SGRSATT_ATTS_CODE in ('LHON','UHON', 'HONR') then 'Y'
        else 'N'
    end Honors_Student,
    SHRDGMR.SHRDGMR_GRAD_DATE Grad_Date

from

    -- IDENTIFICATION
    SPRIDEN SPRIDEN

    left outer join SPBPERS SPBPERS on SPBPERS.SPBPERS_PIDM = SPRIDEN.SPRIDEN_PIDM

    left outer join GORADID GORADID on GORADID.GORADID_PIDM = SPRIDEN.SPRIDEN_PIDM
         and GORADID.GORADID_ADID_CODE = 'SUID'

    -- TERM SELECTION
    join STVTERM STVTERM on STVTERM.STVTERM_CODE is not null
         and STVTERM.STVTERM_CODE = (select max(STVTERM_CODE)
                                    from STVTERM STVTERM1
                                    where STVTERM1.STVTERM_CODE is not null
                                    and STVTERM1.STVTERM_START_DATE < sysdate)


    -- DEGREE MANAGEMENT
    left outer join SHRDGMR SHRDGMR on SHRDGMR.SHRDGMR_PIDM = SPRIDEN.SPRIDEN_PIDM
         --and SHRDGMR.SHRDGMR_TERM_CODE_GRAD = STVTERM.STVTERM_CODE
         and SHRDGMR.SHRDGMR_DEGS_CODE = 'GR'

    --DEGREE INFORMATION
    left outer join SHRDGIH SHRDGIH on SHRDGIH.SHRDGIH_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRDGIH.SHRDGIH_DGMR_SEQ_NO = SHRDGMR.SHRDGMR_SEQ_NO

    -- DEPARTMENTAL DEGREE INFORMATION
    left outer join SHRDGDH SHRDGDH on SHRDGDH.SHRDGDH_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRDGDH.SHRDGDH_DGMR_SEQ_NO = SHRDGMR.SHRDGMR_SEQ_NO

    -- ACADEMIC STANDARDS
    left outer join SHRTTRM SHRTTRM on SHRTTRM.SHRTTRM_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRTTRM.SHRTTRM_TERM_CODE = (select max(SHRTTRM_TERM_CODE)
                                         from SHRTTRM SHRTTRM2
                                         where SHRTTRM2.SHRTTRM_PIDM = SPRIDEN.SPRIDEN_PIDM)

    -- STUDENT ATTRIBUTE DATA (MAX Surrogacy function added 6/29/2022 by BALI04)
    left outer join SGRSATT SGRSATT on SGRSATT.SGRSATT_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SGRSATT.SGRSATT_ATTS_CODE in ('HONR','UHON')
         and SGRSATT.SGRSATT_SURROGATE_ID = (select max(SGRSATT_SURROGATE_ID)
                                           from SGRSATT SGRSATTX
                                           where SGRSATTX.SGRSATT_PIDM = SPRIDEN.SPRIDEN_PIDM
                                           and SGRSATTX.SGRSATT_ATTS_CODE in ('HONR','UHON'))

    -- CUMULATIVE GPA
    left outer join SHRLGPA SHRLGPA on SHRLGPA.SHRLGPA_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SHRLGPA.SHRLGPA_GPA_TYPE_IND = 'I'
         and SHRLGPA.SHRLGPA_LEVL_CODE = SHRDGMR.SHRDGMR_LEVL_CODE

    -- ADDITIONAL DETAILS
    left outer join STVDEGC STVDEGC on STVDEGC.STVDEGC_CODE = SHRDGMR.SHRDGMR_DEGC_CODE
    left outer join STVHONR STVHONR on STVHONR.STVHONR_CODE = SHRDGIH.SHRDGIH_HONR_CODE
    left outer join STVHOND STVHOND on STVHOND.STVHOND_CODE = SHRDGDH.SHRDGDH_HOND_CODE
    left outer join STVMAJR STVMAJR on STVMAJR.STVMAJR_CODE = SHRDGMR.SHRDGMR_MAJR_CODE_1
    left outer join STVMAJR STVMAJR2 on STVMAJR2.STVMAJR_CODE = SHRDGMR.SHRDGMR_MAJR_CODE_MINR_1
    left outer join STVMAJR STVMAJR3 on STVMAJR3.STVMAJR_CODE = SHRDGMR.SHRDGMR_MAJR_CODE_MINR_2
    left outer join STVMAJR STVMAJR4 on STVMAJR4.STVMAJR_CODE = SHRDGMR.SHRDGMR_MAJR_CODE_CONC_1
    --left outer join STVCLAS STVCLAS on STVCLAS.STVCLAS_CODE = f_class_calc_fnc(SHRDGMR.SHRDGMR_PIDM,SHRDGMR.SHRDGMR_LEVL_CODE, STVTERM.STVTERM_CODE)

-- CONDITIONS
where
    SPRIDEN.SPRIDEN_NTYP_CODE is null
    and SPRIDEN.SPRIDEN_CHANGE_IND is null
    and SHRDGMR.SHRDGMR_GRAD_DATE >= to_date(:parm_date_min_select)
    and SHRDGMR.SHRDGMR_GRAD_DATE <= to_date(:parm_date_max_select)
--$addfilter

--$beginorder

-- GROUPING/ORDERING
order by
      SPRIDEN.SPRIDEN_SEARCH_LAST_NAME, SPRIDEN.SPRIDEN_FIRST_NAME

--$endorder