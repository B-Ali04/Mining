-- REPORT FORMAT
select

      -- ESF/SU ID DETAILS
     SPRIDEN.SPRIDEN_ID BANNER_ID,
     SPRIDEN_LAST_NAME Last_Name,
     SPRIDEN_FIRST_NAME First_Name,
     GORADID.GORADID_ADDITIONAL_ID SUID,

     -- ADVISEMENT DETAILS
     SGBSTDN.SGBSTDN_STYP_CODE Reg_Type,
     STVCLAS.STVCLAS_CODE Student_Class,
     STVMAJR.STVMAJR_DESC Program_of_Study,
     STVDEGC.STVDEGC_CODE Degree_Prog,

     -- COURSE REGISTRATION DETAILS
     SSBSECT.SSBSECT_SICAS_CAMP_COURSE_ID Course_Key,
     SSBSECT.SSBSECT_CRN Course_CRN,
     SSBSECT.SSBSECT_SEQ_NUMB Seq_Numb,
     SFRSTCR.SFRSTCR_TERM_CODE Term_Code,
     --SFRSTCR.SFRSTCR_GRDE_CODE Course_Grade,
     case
       when SHRTCKG.SHRTCKG_GRDE_CODE_FINAL is null then SFRSTCR.SFRSTCR_GRDE_CODE
         else SHRTCKG.SHRTCKG_GRDE_CODE_FINAL
       end as Course_Grade,
       /*
    (SELECT
         r.TERM_CODE Previous_Term
     FROM
         REL_STUDENT_ACAD_HISTORY r
     WHERE
         r.PIDM = SPRIDEN.SPRIDEN_PIDM
         and r.term_code = fy_stvterm_prior(fy_stvterm_prior(stvterm_code))--< SFRSTCR.SFRSTCR_TERM_CODE
         and r.SUBJ_CODE = SSBSECT.SSBSECT_SUBJ_CODE
         and r.CRSE_NUMB = SSBSECT.SSBSECT_CRSE_NUMB
         and r.PASSED_IND = 0
         and r.COMPLETE_IND = 0) Previous_Term,
    (SELECT
         r.crn
     FROM
         REL_STUDENT_ACAD_HISTORY r
     WHERE
         r.PIDM = SPRIDEN.SPRIDEN_PIDM
         and r.term_code = fy_stvterm_prior(fy_stvterm_prior(stvterm_code))--< SFRSTCR.SFRSTCR_TERM_CODE
         and r.SUBJ_CODE = SSBSECT.SSBSECT_SUBJ_CODE
         and r.CRSE_NUMB = SSBSECT.SSBSECT_CRSE_NUMB
         and r.PASSED_IND = 0
         and r.COMPLETE_IND = 0) Previous_CRN,
     (SELECT
         r.grde_code
     FROM
         REL_STUDENT_ACAD_HISTORY r
     WHERE
         r.PIDM = SPRIDEN.SPRIDEN_PIDM
         and r.term_code = fy_stvterm_prior(fy_stvterm_prior(stvterm_code))--< SFRSTCR.SFRSTCR_TERM_CODE
         and r.SUBJ_CODE = SSBSECT.SSBSECT_SUBJ_CODE
         and r.CRSE_NUMB = SSBSECT.SSBSECT_CRSE_NUMB
         and r.PASSED_IND = 0
         and r.COMPLETE_IND = 0) Previous_Grade,
         */
     r.CRN Previous_CRN,
     r.TERM_CODE Previous_Term,
     r.GRDE_CODE Previous_Grade,

     -- SORTING FIELDS
     SPRIDEN.SPRIDEN_SEARCH_LAST_NAME,
     STVCLAS.STVCLAS_SURROGATE_ID

from

    -- IDENTIFICATION
    SPRIDEN SPRIDEN

    left outer join GORADID GORADID on GORADID.GORADID_PIDM = SPRIDEN.SPRIDEN_PIDM
         and GORADID.GORADID_ADID_CODE = 'SUID'

    -- TERM SELECTION
    join STVTERM STVTERM on STVTERM.STVTERM_CODE = :parm_term_code_select.STVTERM_CODE

    -- STUDENT DATA
    left outer join SGBSTDN SGBSTDN on SGBSTDN.SGBSTDN_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SGBSTDN.SGBSTDN_TERM_CODE_EFF = fy_sgbstdn_eff_term(SGBSTDN.SGBSTDN_PIDM, STVTERM.STVTERM_CODE)
         and SGBSTDN.SGBSTDN_MAJR_CODE_1 not in ('0000', 'EHS', 'SUS', 'VIS')
         and SGBSTDN.SGBSTDN_STST_CODE in ('AS')

    -- COURSE INFORMATION
    left outer join SFRSTCR SFRSTCR on SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
         and SFRSTCR.SFRSTCR_RSTS_CODE in ('RW', 'RE')

    left outer join SSBSECT SSBSECT on SSBSECT.SSBSECT_CRN = SFRSTCR.SFRSTCR_CRN
         and SSBSECT.SSBSECT_TERM_CODE = SFRSTCR.SFRSTCR_TERM_CODE

    left outer join SHRTCKN SHRTCKN on SHRTCKN.SHRTCKN_PIDM = SFRSTCR.SFRSTCR_PIDM
         and SHRTCKN.SHRTCKN_TERM_CODE = SFRSTCR.SFRSTCR_TERM_CODE
         and SHRTCKN.SHRTCKN_CRN = SFRSTCR.SFRSTCR_CRN

    left outer join SHRTCKG SHRTCKG on SHRTCKG.SHRTCKG_PIDM = SFRSTCR.SFRSTCR_PIDM
         and SHRTCKG.SHRTCKG_TERM_CODE = SHRTCKN.SHRTCKN_TERM_CODE
         and SHRTCKG.SHRTCKG_TCKN_SEQ_NO = SHRTCKN.SHRTCKN_SEQ_NO
         and SHRTCKG.SHRTCKG_SEQ_NO = (select max(SHRTCKG_SEQ_NO)
                                      from SHRTCKG SHRTCKNX
                                      where SHRTCKNX.SHRTCKG_PIDM = SHRTCKG.SHRTCKG_PIDM
                                      and SHRTCKNX.SHRTCKG_TERM_CODE = SHRTCKG.SHRTCKG_TERM_CODE
                                      and SHRTCKNX.SHRTCKG_TCKN_SEQ_NO = SHRTCKG.SHRTCKG_TCKN_SEQ_NO
                                      )
/* removed: replaced with subquery in SELECT statements */
    -- STUDENT COURSE HISTORY
    left outer join REL_STUDENT_ACAD_HISTORY r on r.PIDM = SPRIDEN.SPRIDEN_PIDM
         and r.term_code < SFRSTCR.SFRSTCR_TERM_CODE
         and r.SUBJ_CODE = SSBSECT.SSBSECT_SUBJ_CODE
         and r.CRSE_NUMB = SSBSECT.SSBSECT_CRSE_NUMB
         and r.PASSED_IND = 0
         and r.COMPLETE_IND = 0

    -- ADDITIONAL DETAILS
    left outer join STVMAJR STVMAJR on STVMAJR.STVMAJR_CODE = SGBSTDN.SGBSTDN_MAJR_CODE_1

    left outer join STVDEGC STVDEGC on STVDEGC.STVDEGC_CODE = SGBSTDN.SGBSTDN_DEGC_CODE_1

    left outer join STVCLAS STVCLAS on STVCLAS.STVCLAS_CODE = f_class_calc_fnc(SGBSTDN.SGBSTDN_PIDM,SGBSTDN.SGBSTDN_LEVL_CODE, STVTERM.STVTERM_CODE)

-- CONDITIONS
where
     SPRIDEN.SPRIDEN_NTYP_CODE is null
     and SPRIDEN.SPRIDEN_CHANGE_IND is null
     and(
         not exists(
             select *
             from SFRWDRL SFRWDRL
             where SFRWDRL.SFRWDRL_PIDM = SPRIDEN.SPRIDEN_PIDM
             and SFRWDRL.SFRWDRL_TERM_CODE = SGBSTDN.SGBSTDN_TERM_CODE_EFF
             )

         and 'Y' = f_registered_this_term(SPRIDEN.SPRIDEN_PIDM, STVTERM.STVTERM_CODE)
         )
--$addfilter
--$beginorder

-- GROUPING/ORDERING
order by
     SPRIDEN.SPRIDEN_LAST_NAME
--$endorder