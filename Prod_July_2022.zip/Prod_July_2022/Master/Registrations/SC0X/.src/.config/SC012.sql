SSBSECT.SSBSECT_SICAS_CAMP_COURSE_ID = :parm_course_key_select.course_key
and SGBSTDN.SGBSTDN_MAJR_CODE_1 = 'SUS'