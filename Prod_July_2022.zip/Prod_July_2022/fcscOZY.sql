/*
Hey were to pick up, sgbstdn is writting everything out again uh probably best if you get that out of the way first

*/
SELECT 
       shrtckn.shrtckn_subj_code                               AS subj_code,
       shrtckn.shrtckn_crse_numb                               AS crse_numb,       
       shrtckn.shrtckn_seq_no                                  AS seq_no, 
       shrtckn.shrtckn_crn                                     AS crn,
       shrtckn.shrtckn_coll_code                               AS campus,
--       f_get_desc_fnc('STVMAJR', SGBSTDN.SGBSTDN_MAJR_CODE_1, 30)   AS pos_Desc,       
       F_FORMAT_NAME(shrtckn.shrtckn_pidm, 'LFMI')               AS full_name, 
       GORADID.GORADID_ADDITIONAL_ID                                    AS SUID,
       STVCLAS.STVCLAS_CODE                                    AS Class_Code,
       f_get_desc_fnc('STVTERM',shrtckn.shrtckn_term_code, 30) AS term_code,
       shrtckn.shrtckn_activity_date                           AS Activity_Date,
       f_get_sgbstdn_rowid(shrtckn.shrtckn_pidm, shrtckn_term_code) SGBSTDN_ROWID


FROM   shrtckn shrtckn

left outer join GORADID GORADID on GORADID.GORADID_PIDM = SHRTCKN.SHRTCKN_PIDM
     and GORADID.GORADID_ADID_CODE = 'SUID'

left outer join shrtckl shrtckl on shrtckl.shrtckl_pidm = shrtckn.shrtckn_pidm
     AND shrtckl.shrtckl_term_code = shrtckn.shrtckn_term_code
     AND shrtckl.shrtckl_tckn_seq_no = shrtckn.shrtckn_seq_no

left outer join  shrtckg shrtckg on shrtckg.shrtckg_pidm = shrtckn.shrtckn_pidm
     AND shrtckg.shrtckg_term_code = shrtckn.shrtckn_term_code 
     AND shrtckg.shrtckg_seq_no = shrtckn.shrtckn_seq_no
     AND shrtckg.shrtckg_tckn_seq_no = (SELECT MAX(shrtckg_tckn_seq_no)
                               FROM   shrtckg shrtckg1
                               WHERE  shrtckg1.shrtckg_pidm = shrtckg.shrtckg_pidm
                               AND    shrtckg1.shrtckg_term_code = shrtckg.shrtckg_term_code)


left outer join SGBSTDN SGBSTDN on SGBSTDN.SGBSTDN_PIDM = SHRTCKN.SHRTCKN_PIDM
        and SGBSTDN.SGBSTDN_STST_CODE = 'AS'
        and SGBSTDN.SGBSTDN_TERM_CODE_EFF = fy_sgbstdn_eff_term(SGBSTDN.SGBSTDN_PIDM, shrtckn.shrtckn_term_code)

left outer join STVCLAS STVCLAS on STVCLAS.STVCLAS_CODE = f_class_calc_fnc(SGBSTDN.SGBSTDN_PIDM,SGBSTDN.SGBSTDN_LEVL_CODE, shrtckn.shrtckn_term_Code)

WHERE  
shrtckn.shrtckn_term_code in (202240)--(201820, 201840, 201920, 201940 ) --fall 2017, 

    
    
    and 'Y' = f_registered_this_term(shrtckn.shrtckn_pidm, shrtckn.shrtckn_term_code)
    
    and (shrtckg.shrtckg_gmod_code = 'Y'             
    or (shrtckg.shrtckg_gmod_code is null and shrtckn_coll_code = 'SU'))
--    and SGBSTDN.SGBSTDN_TERM_CODE_EFF = SHRTCKN.SHRTCKN_TERM_CODE
    /*
        and SGBSTDN.SGBSTDN_TERM_CODE_EFF = (SELECT MAX(SGBSTDN.SGBSTDN_TERM_CODE_EFF)
                                            FROM SGBSTDN SGBSTDNX
                                            WHERE SGBSTDNX.SGBSTDN_PIDM = SGBSTDN.SGBSTDN_PIDM
                                            AND SGBSTDNX.SGBSTDN_TERM_CODE_EFF <= SHRTCKN.SHRTCKN_TERM_CODE)
*/
order by
      --shrtckn.shrtckn_term_Code, f_get_desc_fnc('STVDEPT', SGBSTDN.SGBSTDN_DEPT_CODE, 30),
       (shrtckn.shrtckn_subj_code), (shrtckn.shrtckn_crse_numb), F_FORMAT_NAME(shrtckn.shrtckn_pidm, 'LFMI')          
