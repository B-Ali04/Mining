select 
shrtckn.shrtckn_subj_code, shrtckn.shrtckn_crse_numb crse_key,
SCBCRSE.SCBCRSE_TITLE CRSE_TITLE,
SHRTCKN.SHRTCKN_TERM_CODE,
       f_format_name(sirasgn_pidm,'LF30') "Instructor"
       --select * from sirasgn
--f_format_name(rci.id,'LF30') "Instructor",
--rci.LFMI_NAME
/*
shrtckn_subj_code,
shrtckn_crse_numb,

f_get_desc('STVDEPT', SPRIDEN.SPRIDEN_PIDM, 30) --INSTRUCTOR DEPT
--typ
STARTING WITH INSTRUCTORS AND CLASS LIST
*/ 
from
    SHRTCKN SHRTCKN
    left outer join SCBCRSE SCBCRSE on  SHRTCKN.SHRTCKN_SUBJ_CODE = SCBCRSE.SCBCRSE_SUBJ_CODE
        and SCBCRSE.SCBCRSE_CRSE_NUMB = SHRTCKN.SHRTCKN_CRSE_NUMB
        and SCBCRSE.SCBCRSE_EFF_TERM = (select max(SCBCRSE_EFF_TERM)
                            from   SCBCRSE SCBCRSE1
                            where  SCBCRSE1.SCBCRSE_SUBJ_CODE = SHRTCKN.SHRTCKN_SUBJ_CODE
                            and    SCBCRSE1.SCBCRSE_CRSE_NUMB = SHRTCKN.SHRTCKN_CRSE_NUMB
                            and    SCBCRSE1.SCBCRSE_EFF_TERM <= SHRTCKN.SHRTCKN_TERM_CODE)

/* CAPACITY
left outer join shrtckl shrtckl on shrtckl.shrtckl_pidm = shrtckn.shrtckn_pidm
     AND shrtckl.shrtckl_term_code = shrtckn.shrtckn_term_code
     AND shrtckl.shrtckl_tckn_seq_no = shrtckn.shrtckn_seq_no

left outer join  shrtckg shrtckg on shrtckg.shrtckg_pidm = shrtckn.shrtckn_pidm
     AND shrtckg.shrtckg_term_code = shrtckn.shrtckn_term_code 
     AND shrtckg.shrtckg_seq_no = shrtckn.shrtckn_seq_no
     AND shrtckg.shrtckg_tckn_seq_no = (SELECT MAX(shrtckg_tckn_seq_no)
                               FROM   shrtckg shrtckg1
                               WHERE  shrtckg1.shrtckg_pidm = shrtckg.shrtckg_pidm
                               AND    shrtckg1.shrtckg_term_code = shrtckg.shrtckg_term_code)

*/

left outer join SIRASGN SIRASGN on SIRASGN.SIRASGN_PIDM = SHRTCKN.SHRTCKN_PIDM
         and SIRASGN.SIRASGN_TERM_CODE = SHRTCKN.SHRTCKN_TERM_CODE
         and SIRASGN.SIRASGN_CRN = SHRTCKN.SHRTCKN_CRN
         and SIRASGN.SIRASGN_CATEGORY = SHRTCKN.SHRTCKN_SEQ_NUMB
--select * from shrtckn 


/*
     and rci.term_code = shrtckn.shrtckn_term_code
     and rci.crn = shrtckn.shrtckn_crn
*/
--select * from rel_IDENTITY_instructor
--SELECT * FROM REL_IDENTITY_INSTRUCTOR
where
     SHRTCKN.SHRTCKN_TERM_CODE in ( 202140)--= 202240
     AND shrtckn_subj_code = 'APM'

order by
--      F_FORMAT_NAME(shrtckn.shrtckn_pidm, 'LFMI')
        SHRTCKN.SHRTCKN_TERM_CODE, SHRTCKN.SHRTCKN_SUBJ_CODE, SHRTCKN.SHRTCKN_CRSE_NUMB
